package com.devshiv.newsappmvvm.data

object AppConstants {

    const val TAG = "TAG"

    const val APP_BASE_URL = "https://newsapi.org/"
    const val API_KEY = "23aaf1314f7146e1b4ea3dde1f9f1bf0"

    const val COUNTRY = "us"

}