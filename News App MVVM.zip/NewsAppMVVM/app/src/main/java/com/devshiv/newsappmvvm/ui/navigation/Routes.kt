package com.devshiv.newsappmvvm.ui.navigation

object Routes {

    const val HOME_SCREEN = "HOME"

}